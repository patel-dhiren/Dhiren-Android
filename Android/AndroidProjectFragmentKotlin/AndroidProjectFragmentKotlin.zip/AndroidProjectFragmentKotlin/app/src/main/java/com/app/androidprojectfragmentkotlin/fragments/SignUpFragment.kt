package com.app.androidprojectfragmentkotlin.fragments

import android.os.Bundle
import android.util.Patterns
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.app.androidprojectfragmentkotlin.R
import com.app.androidprojectfragmentkotlin.databinding.FragmentSignUpBinding
import java.util.regex.Pattern


class SignUpFragment : Fragment() {

    private val REGEX = ("^(?=.*[0-9])"
            + "(?=.*[a-z])(?=.*[A-Z])"
            + "(?=.*[@#$%^&+=])"
            + "(?=\\S+$).{8,20}$")

    private lateinit var binding:FragmentSignUpBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentSignUpBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnRegister.setOnClickListener {

            var name = binding.etName.text.toString().trim()
            var contact = binding.etContact.text.toString().trim()
            var email = binding.etEmail.text.toString().trim()
            var password = binding.etPassword.text.toString().trim()

            if(name.isEmpty()){
                // show error
                binding.etName.error = "Enter your name"
            }else if(!isValidContact(contact)){
                binding.etContact.error = "Enter valid contact number"
            }else if(!isValidEmail(email)){
                binding.etEmail.error = "Enter valid email address"
            }else if(!isValidPassword(password)) {
                binding.etPassword.error = "Enter valid password"
            }else{
                // navigate to home
                Toast.makeText(requireActivity(), "All fields are validated", Toast.LENGTH_SHORT).show()
            }

        }


    }

    private fun isValidContact(contact:String):Boolean
    {
        return contact.length==10
    }

    private fun isValidEmail(email:String):Boolean{
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    private fun isValidPassword(password:String) : Boolean{
        return Pattern.compile(REGEX).matcher(password).matches()
    }


}